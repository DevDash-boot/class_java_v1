/*
 * Copyright (C) 2022 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.internal;

import static com.google.common.truth.Truth.assertThat;
import static org.junit.Assert.assertThrows;

import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import java.io.Writer;
import org.junit.Test;

public class StreamsTest {
  private static class TestAppendable implements Appendable, Flushable, Closeable {
    boolean closed = false;
    int flushCount = 0;
    Appendable append;

    TestAppendable(Appendable append) {
      this.append = append;
    }

    @Override
    public void close() {
      closed = true;
    }

    @Override
    public void flush() {
      flushCount++;
    }

    @Override
    public TestAppendable append(CharSequence csq) throws IOException {
      append.append(csq);
      return this;
    }

    @Override
    public TestAppendable append(CharSequence csq, int start, int end) throws IOException {
      append.append(csq, start, end);
      return this;
    }

    @Override
    public TestAppendable append(char c) throws IOException {
      append.append(c);
      return this;
    }
  }

  @Test
  public void testWriterForAppendable() throws IOException {
    StringBuilder stringBuilder = new StringBuilder();
    TestAppendable appendable = new TestAppendable(stringBuilder);
    Writer writer = Streams.writerForAppendable(appendable);

    assertThat(appendable.closed).isFalse();
    assertThat(appendable.flushCount).isEqualTo(0);

    writer.append('a');
    writer.append('\u1234');
    writer.append("test");
    writer.append(null); // test custom null handling mandated by `append`
    writer.append("abcdef", 2, 4);
    writer.append(null, 1, 3); // test custom null handling mandated by `append`
    writer.append(',');

    writer.write('a');
    writer.write('\u1234');
    // Should only consider the 16 low-order bits
    writer.write(0x4321_1234);
    writer.append(',');

    writer.write("chars".toCharArray());
    assertThrows(NullPointerException.class, () -> writer.write((char[]) null));

    writer.write("chars".toCharArray(), 1, 2);
    assertThrows(NullPointerException.class, () -> writer.write((char[]) null, 1, 2));
    writer.append(',');

    writer.write("string");
    assertThrows(NullPointerException.class, () -> writer.write((String) null));

    writer.write("string", 1, 2);
    assertThrows(NullPointerException.class, () -> writer.write((String) null, 1, 2));

    String actualOutput = stringBuilder.toString();
    assertThat(actualOutput).isEqualTo("a\u1234testnullcdul,a\u1234\u1234,charsha,stringtr");

    writer.flush();
    writer.close();

    assertThat(appendable.closed).isTrue();
    assertThat(appendable.flushCount).isEqualTo(1);

    assertThat(stringBuilder.toString()).isEqualTo(actualOutput);
  }
}
